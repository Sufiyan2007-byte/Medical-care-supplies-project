import { useState, useEffect, useRef } from 'react';
import { Outlet, Link, NavLink, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { FaInstagram, FaXTwitter, FaWhatsapp } from 'react-icons/fa6';
import { useAuthContext } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import CartPanel from '../components/CartPanel';
import './MainLayout.css';
import { logoSrc } from '../utils/themes';

/* ── Inline SVG icons (no extra dep) ─────────────────────────────────────── */
const Icon = {
  home: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
      <polyline points="9 22 9 12 15 12 15 22"/>
    </svg>
  ),
  about: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/>
      <line x1="12" y1="8" x2="12" y2="12"/>
      <line x1="12" y1="16" x2="12.01" y2="16"/>
    </svg>
  ),
  products: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
    </svg>
  ),
  contact: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4 2 2 0 0 1 3.6 1.22h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.8a16 16 0 0 0 6.29 6.29l.96-.96a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>
    </svg>
  ),
  cart: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="9" cy="21" r="1"/>
      <circle cx="20" cy="21" r="1"/>
      <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
    </svg>
  ),
  login: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
      <polyline points="10 17 15 12 10 7"/>
      <line x1="15" y1="12" x2="3" y2="12"/>
    </svg>
  ),
  logout: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
      <polyline points="16 17 21 12 16 7"/>
      <line x1="21" y1="12" x2="9" y2="12"/>
    </svg>
  ),
  lang: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/>
      <line x1="2" y1="12" x2="22" y2="12"/>
      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
    </svg>
  ),
  admin: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
      <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
    </svg>
  ),
  user: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
      <circle cx="12" cy="7" r="4"/>
    </svg>
  ),
  orders: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
      <line x1="3" y1="6" x2="21" y2="6"/>
      <path d="M16 10a4 4 0 0 1-8 0"/>
    </svg>
  ),
  chevron: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="15 18 9 12 15 6"/>
    </svg>
  ),
  search: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="8"/>
      <line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
  ),
  menu: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="3" y1="6" x2="21" y2="6"/>
      <line x1="3" y1="12" x2="21" y2="12"/>
      <line x1="3" y1="18" x2="21" y2="18"/>
    </svg>
  ),
  close: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
    </svg>
  ),
};

/* ── Nav link definitions ─────────────────────────────────────────────────── */
const NAV_ITEMS = [
  { to: '/',        labelKey: 'nav.home',     icon: 'home',     exact: true },
  { to: '/about',   labelKey: 'nav.about',    icon: 'about'   },
  { to: '/products',labelKey: 'nav.products', icon: 'products',
    children: [
      { to: '/products/surgical-instruments', labelKey: 'products.title_surgical_instruments', fallback: 'Surgical Instruments' },
      { to: '/products/medical-consumables',  labelKey: 'products.title_medical_consumables',  fallback: 'Medical Consumables'  },
      { to: '/products/surgical-sets',        labelKey: 'products.title_surgical_sets',         fallback: 'Surgical Sets'        },
      { to: '/products/ent-rhinology',        labelKey: 'ent.nav_label',                        fallback: 'ENT & Diagnostics'    },
      { to: '/products/general-surgery',      labelKey: 'products.title_general_surgery',       fallback: 'General Surgery Catalog' },
    ],
  },
  { to: '/contact', labelKey: 'nav.contact',  icon: 'contact' },
];

/* ═══════════════════════════════════════════════════════════════════════════ */

function MainLayout() {
  const { t, i18n } = useTranslation();
  const { isAuthenticated, user, logout } = useAuthContext();
  const { cartCount, setIsCartOpen } = useCart();

  const [collapsed, setCollapsed]       = useState(false);   // sidebar collapsed to rail
  const [mobileOpen, setMobileOpen]     = useState(false);   // mobile drawer open
  const [productsOpen, setProductsOpen] = useState(false);   // products sub-menu

  const closeAll = () => { setMobileOpen(false); setProductsOpen(false); };

  /* ── Sidebar search ───────────────────────────────────────────────────── */
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const searchRef = useRef(null);

  const handleSearch = (e) => {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;
    navigate(`/products/ent-rhinology?q=${encodeURIComponent(q)}`);
    closeAll();
  };

  // Press "/" anywhere to jump to the search box
  useEffect(() => {
    const onKey = (e) => {
      const tag = (e.target.tagName || '').toLowerCase();
      if (e.key !== '/' || tag === 'input' || tag === 'textarea' || e.target.isContentEditable) return;
      e.preventDefault();
      searchRef.current?.focus();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const toggleLanguage = () => {
    const newLang = i18n.language.startsWith('en') ? 'ar' : 'en';
    i18n.changeLanguage(newLang);
    document.documentElement.dir = newLang.startsWith('ar') ? 'rtl' : 'ltr';
    document.documentElement.lang = newLang;
  };

  useEffect(() => {
    document.documentElement.dir = i18n.language.startsWith('ar') ? 'rtl' : 'ltr';
    document.documentElement.lang = i18n.language;
  }, [i18n.language]);

  const isRTL = i18n.language.startsWith('ar');
  const isStaff = user?.role === 'admin' || user?.role === 'developer';
  const SIDEBAR_W = collapsed ? 72 : 280;

  return (
    <div className={`site-wrapper${collapsed ? ' sidebar-collapsed' : ''}`}>

      {/* ══ SIDEBAR ════════════════════════════════════════════════════════ */}
      <aside
        className={`sidebar${collapsed ? ' sidebar--collapsed' : ''}`}
        aria-label="Site navigation"
      >
        {/* Top: logo + account card */}
        <div className="sidebar-top">
          <Link to="/" className="sidebar-logo" onClick={closeAll} aria-label="Medical Care Supplies">
            <img
              src={collapsed ? '/logo_mark.png' : logoSrc()}
              alt="Medical Care Supplies"
              className="sidebar-logo-img"
            />
            {!collapsed && <span className="sidebar-logo-tagline">Medical Care Supplies</span>}
          </Link>
          {isAuthenticated ? (
            <Link
              to={isStaff ? '/staff' : '/account'}
              className="sidebar-account"
              onClick={closeAll}
              title={collapsed ? (user?.name || user?.email) : undefined}
            >
              <span className="sidebar-account-avatar" aria-hidden="true">
                {(user?.name || user?.email || '?').trim().charAt(0).toUpperCase()}
              </span>
              {!collapsed && (
                <span className="sidebar-account-text">
                  <span className="sidebar-account-title">
                    {isRTL ? 'مرحباً،' : 'Welcome,'} {user?.name || user?.email}
                  </span>
                  <span className="sidebar-account-sub">
                    {isStaff ? (isRTL ? 'لوحة الموظفين' : 'Staff panel') : (isRTL ? 'حسابي وطلباتي' : 'My account & orders')}
                  </span>
                </span>
              )}
            </Link>
          ) : (
            <Link
              to="/auth/login"
              className="sidebar-account"
              onClick={closeAll}
              title={collapsed ? (isRTL ? 'تسجيل الدخول' : 'Sign in') : undefined}
            >
              <span className="sidebar-account-avatar" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="20" height="20">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
              </span>
              {!collapsed && (
                <span className="sidebar-account-text">
                  <span className="sidebar-account-title">
                    {isRTL ? 'مرحباً بك' : 'Welcome'}
                  </span>
                  <span className="sidebar-account-sub">
                    {isRTL ? 'سجّل الدخول لإتمام الطلب' : 'Sign in to place orders'}
                  </span>
                </span>
              )}
            </Link>
          )}
        </div>

        {/* Middle: main nav links */}
        <nav className="sidebar-nav">
          {NAV_ITEMS.map(item => {
            const hasChildren = item.children?.length > 0;
            return (
              <div key={item.to} className="sidebar-nav-item-wrap">
                {hasChildren ? (
                  <>
                    <button
                      className={`sidebar-nav-link sidebar-nav-btn${productsOpen ? ' active-parent' : ''}`}
                      onClick={() => setProductsOpen(v => !v)}
                      title={collapsed ? t(item.labelKey) : undefined}
                    >
                      <span className="nav-icon">{Icon[item.icon]}</span>
                      {!collapsed && <span className="nav-label">{t(item.labelKey)}</span>}
                      {!collapsed && (
                        <span className={`nav-sub-arrow${productsOpen ? ' open' : ''}`}>
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="14" height="14">
                            <polyline points="6 9 12 15 18 9"/>
                          </svg>
                        </span>
                      )}
                    </button>
                    {!collapsed && productsOpen && (
                      <div className="sidebar-subnav">
                        {item.children.map(child => (
                          <NavLink
                            key={child.to}
                            to={child.to}
                            className={({ isActive }) => `sidebar-sublink${isActive ? ' active' : ''}`}
                            onClick={closeAll}
                          >
                            {t(child.labelKey, child.fallback)}
                          </NavLink>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <NavLink
                    to={item.to}
                    end={item.exact}
                    className={({ isActive }) => `sidebar-nav-link${isActive ? ' active' : ''}`}
                    onClick={closeAll}
                    title={collapsed ? t(item.labelKey) : undefined}
                  >
                    <span className="nav-icon">{Icon[item.icon]}</span>
                    {!collapsed && <span className="nav-label">{t(item.labelKey)}</span>}
                  </NavLink>
                )}
              </div>
            );
          })}
        </nav>

        {/* Bottom: cart, auth, language, admin */}
        <div className="sidebar-bottom">

          {/* Cart */}
          <button
            className="sidebar-nav-link sidebar-nav-btn sidebar-cart-btn"
            onClick={() => setIsCartOpen(true)}
            title={collapsed ? t('cart.title', 'Cart') : undefined}
          >
            <span className="nav-icon nav-icon--cart">
              {Icon.cart}
              {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
            </span>
            {!collapsed && <span className="nav-label">{t('cart.title', 'Cart')}</span>}
            {!collapsed && cartCount > 0 && (
              <span className="sidebar-cart-count">{cartCount}</span>
            )}
          </button>

          {/* Language */}
          <button
            className="sidebar-nav-link sidebar-nav-btn"
            onClick={toggleLanguage}
            title={collapsed ? (i18n.language.startsWith('en') ? 'العربية' : 'English') : undefined}
          >
            <span className="nav-icon">{Icon.lang}</span>
            {!collapsed && (
              <span className="nav-label">
                {i18n.language.startsWith('en') ? 'العربية' : 'English'}
              </span>
            )}
          </button>

          {/* Staff panel (admin / developer) or customer account links */}
          {isStaff && (
            <NavLink
              to="/staff"
              className="sidebar-nav-link sidebar-nav-link--staff"
              onClick={closeAll}
              title={collapsed ? (isRTL ? 'لوحة الموظفين' : 'Staff panel') : undefined}
            >
              <span className="nav-icon">{Icon.admin}</span>
              {!collapsed && <span className="nav-label">{isRTL ? 'لوحة الموظفين' : 'Staff panel'}</span>}
            </NavLink>
          )}
          {isAuthenticated && !isStaff && (
            <>
              <NavLink
                to="/account"
                end
                className={({ isActive }) => `sidebar-nav-link${isActive ? ' active' : ''}`}
                onClick={closeAll}
                title={collapsed ? (isRTL ? 'حسابي' : 'My account') : undefined}
              >
                <span className="nav-icon">{Icon.user}</span>
                {!collapsed && <span className="nav-label">{isRTL ? 'حسابي' : 'My account'}</span>}
              </NavLink>
              <NavLink
                to="/account/orders"
                className={({ isActive }) => `sidebar-nav-link${isActive ? ' active' : ''}`}
                onClick={closeAll}
                title={collapsed ? (isRTL ? 'طلباتي' : 'My orders') : undefined}
              >
                <span className="nav-icon">{Icon.orders}</span>
                {!collapsed && <span className="nav-label">{isRTL ? 'طلباتي' : 'My orders'}</span>}
              </NavLink>
            </>
          )}

          {/* Login / Logout */}
          {isAuthenticated ? (
            <>
              {!collapsed && (
                <div className="sidebar-user-badge">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="14" height="14">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                  </svg>
                  <span>{user?.name || user?.email}</span>
                </div>
              )}
              <button
                className="sidebar-nav-link sidebar-nav-btn sidebar-logout-btn"
                onClick={logout}
                title={collapsed ? t('nav.logout') : undefined}
              >
                <span className="nav-icon">{Icon.logout}</span>
                {!collapsed && <span className="nav-label">{t('nav.logout')}</span>}
              </button>
            </>
          ) : (
            <NavLink
              to="/auth/login"
              className={({ isActive }) => `sidebar-nav-link${isActive ? ' active' : ''}`}
              onClick={closeAll}
              title={collapsed ? t('nav.sign_in') : undefined}
            >
              <span className="nav-icon">{Icon.login}</span>
              {!collapsed && <span className="nav-label">{t('nav.sign_in')}</span>}
            </NavLink>
          )}
        </div>
      </aside>

      {/* Collapse toggle — floats on the sidebar edge */}
      <button
        className="sidebar-collapse-btn"
        onClick={() => setCollapsed(v => !v)}
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        title={collapsed ? 'Expand' : 'Collapse'}
        style={isRTL ? { right: `${SIDEBAR_W}px`, left: 'auto' } : { left: `${SIDEBAR_W}px`, right: 'auto' }}
      >
        <span className={`collapse-chevron${collapsed ? ' rotated' : ''}`}>
          {Icon.chevron}
        </span>
      </button>

      {/* ══ MOBILE TOP BAR ═════════════════════════════════════════════════ */}
      <header className="mobile-topbar">
        <Link to="/" className="mobile-topbar-logo" onClick={closeAll}>
          <img src={logoSrc()} alt="Logo" />
        </Link>

        <div className="mobile-topbar-actions">
          <button
            className="mobile-icon-btn"
            onClick={() => setIsCartOpen(true)}
            aria-label="Open cart"
          >
            <span className="nav-icon--cart" style={{ position: 'relative', display: 'inline-flex' }}>
              {Icon.cart}
              {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
            </span>
          </button>

          <button className="mobile-icon-btn" onClick={toggleLanguage} aria-label="Switch language">
            {i18n.language.startsWith('en') ? 'ع' : 'EN'}
          </button>

          <button
            className={`mobile-icon-btn hamburger-btn${mobileOpen ? ' open' : ''}`}
            onClick={() => setMobileOpen(v => !v)}
            aria-label="Toggle menu"
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? Icon.close : Icon.menu}
          </button>
        </div>
      </header>

      {/* ══ MOBILE DRAWER ══════════════════════════════════════════════════ */}
      {mobileOpen && (
        <div className="mobile-drawer-backdrop" onClick={closeAll} />
      )}
      <nav className={`mobile-drawer${mobileOpen ? ' open' : ''}`} aria-hidden={!mobileOpen}>
        {NAV_ITEMS.map(item => {
          const hasChildren = item.children?.length > 0;
          return (
            <div key={item.to} className="mobile-drawer-item-wrap">
              {hasChildren ? (
                <>
                  <button
                    className="mobile-drawer-link mobile-drawer-btn"
                    onClick={() => setProductsOpen(v => !v)}
                  >
                    <span className="nav-icon">{Icon[item.icon]}</span>
                    {t(item.labelKey)}
                    <span className={`nav-sub-arrow${productsOpen ? ' open' : ''}`}>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="14" height="14">
                        <polyline points="6 9 12 15 18 9"/>
                      </svg>
                    </span>
                  </button>
                  {productsOpen && (
                    <div className="mobile-drawer-subnav">
                      {item.children.map(child => (
                        <NavLink
                          key={child.to}
                          to={child.to}
                          className={({ isActive }) => `mobile-drawer-sublink${isActive ? ' active' : ''}`}
                          onClick={closeAll}
                        >
                          {t(child.labelKey, child.fallback)}
                        </NavLink>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <NavLink
                  to={item.to}
                  end={item.exact}
                  className={({ isActive }) => `mobile-drawer-link${isActive ? ' active' : ''}`}
                  onClick={closeAll}
                >
                  <span className="nav-icon">{Icon[item.icon]}</span>
                  {t(item.labelKey)}
                </NavLink>
              )}
            </div>
          );
        })}

        <div className="mobile-drawer-footer">
          {isStaff && (
            <NavLink to="/staff" className="mobile-drawer-link" onClick={closeAll}>
              <span className="nav-icon">{Icon.admin}</span>
              {isRTL ? 'لوحة الموظفين' : 'Staff panel'}
            </NavLink>
          )}
          {isAuthenticated && !isStaff && (
            <>
              <NavLink to="/account" end className="mobile-drawer-link" onClick={closeAll}>
                <span className="nav-icon">{Icon.user}</span>
                {isRTL ? 'حسابي' : 'My account'}
              </NavLink>
              <NavLink to="/account/orders" className="mobile-drawer-link" onClick={closeAll}>
                <span className="nav-icon">{Icon.orders}</span>
                {isRTL ? 'طلباتي' : 'My orders'}
              </NavLink>
            </>
          )}
          {isAuthenticated ? (
            <>
              <div className="mobile-drawer-user">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="16" height="16">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                  <circle cx="12" cy="7" r="4"/>
                </svg>
                {user?.name || user?.email}
              </div>
              <button className="mobile-drawer-link mobile-drawer-btn mobile-logout"
                onClick={() => { logout(); closeAll(); }}>
                <span className="nav-icon">{Icon.logout}</span>
                {t('nav.logout')}
              </button>
            </>
          ) : (
            <NavLink to="/auth/login" className="mobile-drawer-signin" onClick={closeAll}>
              <span className="nav-icon">{Icon.login}</span>
              {t('nav.sign_in')}
            </NavLink>
          )}
        </div>
      </nav>

      {/* ══ MAIN + FOOTER (shifted by sidebar on desktop) ════════════════ */}
      <div className="site-body">
        <header className="site-topbar">
          <form className="site-topbar-search" role="search" onSubmit={handleSearch}>
            <span className="site-topbar-search-icon" aria-hidden="true">{Icon.search}</span>
            <input
              ref={searchRef}
              type="search"
              className="site-topbar-search-input"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={isRTL ? 'ابحث عن أداة جراحية أو رقم صنف…' : 'Search surgical instruments or SKU…'}
              aria-label={isRTL ? 'بحث في المنتجات' : 'Search products'}
            />
            <kbd className="site-topbar-search-kbd" aria-hidden="true">/</kbd>
          </form>

          <div className="site-topbar-actions">
            <Link to="/contact" className="site-topbar-contact">
              {isRTL ? 'اطلب عرض سعر' : 'Request a quote'}
            </Link>
            <button
              type="button"
              className="site-topbar-cart"
              onClick={() => setIsCartOpen(true)}
              aria-label={t('cart.title', 'Cart')}
            >
              {Icon.cart}
              {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
            </button>
          </div>
        </header>
        <main className="site-main">
          <Outlet />
        </main>

        <footer className="site-footer">
          <div className="footer-top">
            <div className="footer-brand">
              <Link to="/" className="site-logo">
                <div className="footer-logo-card">
                  <img src={logoSrc()} alt="Medical Care Supplies Logo" className="footer-logo-img" />
                </div>
              </Link>
              <p className="footer-address">
                {t('contact.address', '123 Medical St, Riyadh, Saudi Arabia')}
              </p>
            </div>
            <div className="footer-nav">
              <Link to="/">{t('nav.home')}</Link>
              <Link to="/about">{t('nav.about')}</Link>
              <Link to="/products">{t('nav.products')}</Link>
              <Link to="/contact">{t('nav.contact')}</Link>
            </div>
            <div className="footer-contact">
              <div className="footer-socials">
                <a href="mailto:info@medicaresupplies.net" className="social-icon email-link">
                  info@medicaresupplies.net
                </a>
                <div className="social-icons-row">
                  <a href="#" target="_blank" rel="noopener noreferrer" className="social-icon"><FaInstagram size={20} /></a>
                  <a href="#" target="_blank" rel="noopener noreferrer" className="social-icon"><FaXTwitter size={20} /></a>
                  <a href="#" target="_blank" rel="noopener noreferrer" className="social-icon"><FaWhatsapp size={20} /></a>
                </div>
              </div>
            </div>
          </div>
          <div className="footer-bottom">
            <div className="footer-copyright">
              {t('footer.rights_reserved', { year: new Date().getFullYear() })}
            </div>
          </div>
        </footer>
      </div>

      <CartPanel />
    </div>
  );
}

export default MainLayout;
